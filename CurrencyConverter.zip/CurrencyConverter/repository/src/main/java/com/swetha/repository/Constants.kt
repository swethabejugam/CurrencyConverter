package com.swetha.repository

class Constants {
    companion object{
       const val  BASE_URL="https://revolut.duckdns.org"
    }

}