package com.swetha.repository.model

data class RatesList(var currencyCode:String,var rate:Float)