package com.swetha.repository.model

data class RatesResponse(var base:String,var date:String,var rates:Map<String,Float>)