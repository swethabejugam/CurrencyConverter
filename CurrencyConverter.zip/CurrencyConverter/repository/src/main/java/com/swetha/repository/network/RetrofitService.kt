package com.swetha.repository.network

import com.swetha.repository.model.RatesResponse
import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.Query

interface RetrofitService{


    @GET("/latest")
    fun getRatesResponse(@Query("base")base : String): Single<RatesResponse>
}