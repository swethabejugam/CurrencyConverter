package com.swetha.currency

import android.content.Context
import com.swetha.currency.CurrencyConverter.CurrenciesFragment
import com.swetha.currency.CurrencyConverter.CurrenciesViewModel
import com.swetha.repository.di.ServiceModule
import dagger.BindsInstance
import dagger.Component
import dagger.Subcomponent
import javax.inject.Singleton

@Singleton
@Component(modules=[ServiceModule::class])
interface AppComponent {

    fun inject(currenciesViewModel: CurrenciesViewModel)

}
