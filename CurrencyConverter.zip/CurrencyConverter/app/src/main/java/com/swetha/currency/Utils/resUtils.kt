package com.swetha.currency.Utils

import android.content.Context


/**
 * Returns the currency name resource id using its currencycode
 */
fun getCurrencyNameResId(context: Context, currencyCode: String) =
    context.resources.getIdentifier("currency_" + currencyCode + "_name", "string",
        context.packageName)

/**
 * Returns the currency flag resource id using its currencycode
 */
fun getCurrencyFlagResId(context: Context, currencyCode: String) = context.resources.getIdentifier(
    "ic_" + currencyCode + "_flag", "drawable", context.packageName)

