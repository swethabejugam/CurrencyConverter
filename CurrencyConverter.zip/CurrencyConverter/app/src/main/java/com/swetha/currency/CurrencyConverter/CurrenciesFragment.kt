package com.swetha.currency.CurrencyConverter

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.swetha.currency.R
import com.swetha.currency.databinding.FragmentCurrenciesBinding
import com.swetha.currency.listener.ConverterListener
import com.swetha.currency.listener.CurrencyConverterAdapterListener
import com.swetha.repository.model.RatesList
import java.util.*


class CurrenciesFragment : Fragment(), ConverterListener {

    private val viewModel: CurrenciesViewModel by lazy {
        val activity = requireNotNull(this.activity) {
            "You can only access the viewModel after onActivityCreated()"
        }
        ViewModelProviders.of(this, CurrenciesViewModelFactory(activity.application))
            .get(CurrenciesViewModel::class.java)
    }

    lateinit var errorSnackbar:Snackbar
    lateinit var  binding: FragmentCurrenciesBinding
    lateinit var adapter: CurrenciesListAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate view and obtain an instance of the binding class.
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_currencies,
            container,
            false
        )
        viewModel.onActivityCreated()
//        viewModel.isOnline?.observe(this,androidx.lifecycle.Observer {
//            if(!it){
//                showErrorMessage(getString(R.string.check_net_connection))
//            }
//        })

        binding.setLifecycleOwner(this)

        adapter = CurrenciesListAdapter(object : CurrencyConverterAdapterListener {
            @Override
            override fun onItemClick(position: Int, currencyCode: String, rate: Float) {

                (binding.currenciesList.getLayoutManager() as LinearLayoutManager).scrollToPosition(0)//binding.currenciesList,binding.currenciesList.scrollState,0 ) // scroll recyclerview to top
                viewModel.checkRates(currencyCode,rate)

            }

            override fun onAmountChanged(editedAmount: Float, code: String) {

                updateAmount(code,editedAmount)

            }

        })

        binding.currenciesList.adapter = adapter
        return binding.root
    }


    override fun updateAmount(base: String, amount: Float) {
        adapter.updateAmount(amount)    }

    override fun updateRatesList(rates: ArrayList<RatesList>) {
         adapter.updateRates(rates)
        binding.progressBar.visibility=View.GONE

    }

    override fun showLoading(b: Boolean) {
        binding.progressBar.visibility=View.VISIBLE
        dismissSnackBar()
    }

    override fun showErrorMessage(localizedMessage: String?) {
        if (localizedMessage != null) {
            binding.progressBar.visibility=View.GONE
            errorSnackbar= Snackbar.make(binding.root, localizedMessage, Snackbar.LENGTH_INDEFINITE)
            errorSnackbar.setAction(R.string.retry, {viewModel.reqCall()})
            errorSnackbar.show()
        }

    }

    override fun onAttach(context: Context) {

        super.onAttach(context)
        viewModel.converterListener = this

    }
   fun dismissSnackBar(){
       if(::errorSnackbar.isInitialized) {
           errorSnackbar.dismiss()
       }
   }




}

