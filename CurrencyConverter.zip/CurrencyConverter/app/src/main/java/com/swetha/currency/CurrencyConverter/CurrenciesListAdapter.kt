package com.swetha.currency.CurrencyConverter

import android.annotation.SuppressLint
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.swetha.currency.Utils.format
import com.swetha.currency.Utils.getCurrencyFlagResId
import com.swetha.currency.Utils.getCurrencyNameResId
import com.swetha.currency.Utils.toFloat
import com.swetha.currency.databinding.ItemCurrencyListBinding
import com.swetha.currency.listener.CurrencyConverterAdapterListener
import com.swetha.repository.model.RatesList
import java.util.HashMap

class CurrenciesListAdapter internal constructor(
    val listener: CurrencyConverterAdapterListener
) : RecyclerView.Adapter<CurrenciesListAdapter.CurrencyViewHolder>() {

    private var amount = 1.0F

    private val symbolPosition = ArrayList<String>()
    private val symbolRate = HashMap<String, RatesList>()

    inner class CurrencyViewHolder(private var binding: com.swetha.currency.databinding.ItemCurrencyListBinding) :
        RecyclerView.ViewHolder(binding.root) {

        @SuppressLint("ClickableViewAccessibility")
        fun bind(ratesList: RatesList) {
            val flagId = getCurrencyFlagResId(itemView.context, ratesList.currencyCode.toLowerCase())
            binding.icon.setImageResource(flagId)
            if (!binding.edtamount.isFocused) {
                binding.edtamount.setText((ratesList.rate * amount).format())
            }
            binding.tvHeader.setText(ratesList.currencyCode)
            binding.tvSubheader.setText(getCurrencyNameResId(itemView.context, ratesList.currencyCode.toLowerCase()))

            binding.edtamount.setOnTouchListener(object : View.OnTouchListener {
                override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                    when (event?.action) {
                        MotionEvent.ACTION_DOWN ->
                            if(position!=0){
                                //We move it from its current position
                                symbolPosition.removeAt(position).also {
                                    //And we add it to the top
                                    symbolPosition.add(0, it)
                                }

                                //We notify the recyclerview the view moved to position 0
                                notifyItemMoved(position, 0)
                                listener.onItemClick(position, ratesList.currencyCode, ratesList.rate)
                            }
                    }

                    return v?.onTouchEvent(event) ?: true
                }
            })

            binding.edtamount.addTextChangedListener(object : TextWatcher {
                override fun onTextChanged(s: CharSequence?, p1: Int, p2: Int, p3: Int) {
                    if (binding.edtamount.hasFocus()) {
                        listener.onAmountChanged(s.toString().toFloat(), ratesList.currencyCode)
                    }
                }

                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                }

                override fun afterTextChanged(p0: Editable?) {
                }

            })

            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CurrencyViewHolder {
        return CurrencyViewHolder(ItemCurrencyListBinding.inflate(LayoutInflater.from(parent.context)))
    }

    override fun onBindViewHolder(holder: CurrencyViewHolder, position: Int) {
        val currency = rateAtPosition(position)
        holder.bind(rateAtPosition(position))
        holder.itemView.setOnClickListener({

            //We move it from its current position
            symbolPosition.removeAt(position).also {
                //And we add it to the top
                symbolPosition.add(0, it)
            }

            //We notify the recyclerview the view moved to position 0
            notifyItemMoved(position, 0)
            listener.onItemClick(position, currency.currencyCode, currency.rate)
            //updating the amount to 1.0
            this.amount=1.0F

        })



    }

    override fun getItemCount() = symbolPosition.size

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }


    fun updateRates(rates: ArrayList<RatesList>) {
        if (symbolPosition.isEmpty()) {
            symbolPosition.addAll(rates.map { it.currencyCode })
        }

        for (rate in rates) {
            symbolRate[rate.currencyCode] = rate
        }

        notifyItemRangeChanged(0, symbolPosition.size - 1, amount)
    }

    /**
     * Update the amount
     */
    fun updateAmount(amount: Float) {
        this.amount = amount

        notifyItemRangeChanged(0, symbolPosition.size - 1, amount)
    }


    /**
     * Returns the rate at the given position
     */
    private fun rateAtPosition(pos: Int): RatesList {
        return symbolRate[symbolPosition[pos]]!!
    }
}