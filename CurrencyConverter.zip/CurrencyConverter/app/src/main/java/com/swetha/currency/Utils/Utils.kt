package com.swetha.currency.Utils

import android.content.Context
import android.net.ConnectivityManager
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*

/**
 * Parse and returns a float from the string
 * Locale safe
 */
fun String.toFloat(): Float = if (isNullOrBlank()) {
    0F
} else {
    DecimalFormat("0.#", DecimalFormatSymbols.getInstance(Locale.getDefault())).parse(this).toFloat()
}

/**
 * Format the float to string
 * Locale safe
 */
fun  Float.format() : String = String.format(Locale.getDefault(), "%.2f", this)

fun isOnline(context: Context): Boolean {
    val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val networkInfo = connectivityManager.activeNetworkInfo
    return networkInfo != null && networkInfo.isConnected
}