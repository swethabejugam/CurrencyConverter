package com.swetha.currency.listener

import com.swetha.repository.model.RatesList
import java.util.ArrayList

interface ConverterListener {

    fun updateAmount(base: String, amount: Float)

    fun updateRatesList(rates: ArrayList<RatesList>)

    fun showLoading(b: Boolean)

    fun showErrorMessage(localizedMessage: String?)


}