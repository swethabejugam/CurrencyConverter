package com.swetha.currency.listener

interface CurrencyConverterAdapterListener {

    fun onItemClick(position: Int, currencyCode: String, rate: Float)
    fun onAmountChanged(editedAmount: Float, code: String)

}