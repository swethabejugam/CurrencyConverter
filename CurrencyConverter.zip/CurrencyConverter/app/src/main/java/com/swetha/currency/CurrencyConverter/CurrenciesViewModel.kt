package com.swetha.currency.CurrencyConverter

import android.app.Application

import androidx.lifecycle.AndroidViewModel
import com.swetha.currency.DaggerAppComponent
import com.swetha.currency.R
import com.swetha.currency.Utils.isOnline
import com.swetha.currency.listener.ConverterListener
import com.swetha.repository.model.RatesList
import com.swetha.repository.network.RetrofitService
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class CurrenciesViewModel(application: Application) : AndroidViewModel(application) {

    internal lateinit var converterListener: ConverterListener
    private var currentBase = ""
    private var viewStopped = false
    private var isLoaded = false

    @Inject
    lateinit var retrofitService: RetrofitService
    private val context = getApplication<Application>().applicationContext

    companion object {
        const val DEFAULT_SYMBOL = "EUR"
    }

    /**
     * Handle the onActivityCreated() of the fragment
     */
    init {
        DaggerAppComponent.create().inject(this)

    }

    fun onActivityCreated() {
        checkRates(DEFAULT_SYMBOL, 1F)

    }

    internal fun reqCall() {
        if(isOnline(context)) {
            if (currentBase.equals("")) {
                sendReq(DEFAULT_SYMBOL)
            } else {
                sendReq(currentBase)
            }
        }else{
            converterListener.showErrorMessage(context.getString(R.string.check_net_connection))

        }

    }


    internal fun checkRates(base: String, amount: Float) {
        if (isOnline(context)) {

            if (base.equals(currentBase, ignoreCase = true)) {
                converterListener.updateAmount(base, amount)
            } else {
                sendReq(base)
            }
        } else {
            if(!currentBase.equals("")) {
                currentBase = base
            }
            converterListener.showErrorMessage(context.getString(R.string.check_net_connection))

        }


    }

    private fun sendReq(base: String) {
        currentBase = base.toUpperCase()
        retrofitService.getRatesResponse(currentBase)
            .doOnSubscribe {
                if (!isLoaded) {
                    converterListener.showLoading(true)
                }
            }
            .delay(1, TimeUnit.SECONDS)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .repeatUntil({ viewStopped || !base.equals(currentBase, ignoreCase = true) })
            .doOnError {
                converterListener.showErrorMessage(context.getString(R.string.error_msg))

            }
            .subscribe({

                val rates = ArrayList<RatesList>()
                rates.add(RatesList(it.base, 1.0F))

                rates.addAll(it.rates.map { RatesList(it.key, it.value) })

                converterListener.updateRatesList(rates)
                if (!isLoaded) {
                    converterListener.showLoading(false)
                }
                isLoaded = true
            }, {
                converterListener.showErrorMessage(context.getString(R.string.error_msg))
            })
    }

    override fun onCleared() {
        super.onCleared()
        viewStopped = true
    }
}