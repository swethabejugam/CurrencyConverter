package com.swetha.currency

import android.app.Application
import com.swetha.currency.Utils.ReleaseTree

import timber.log.Timber


class CurrencyConverterApplication :Application(){


    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree());
        } else {
            Timber.plant(ReleaseTree());
        }


    }

}