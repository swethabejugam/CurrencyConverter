Currency Converter is a sample Android application written in Kotlin.
This App implements one screen with a list of currencies. Here is the screen:
https://www.figma.com/file/cUsxw4zNAvU47ADDCJemBM/Rates

The app downloads and update rates every 1 second using API
https://revolut.duckdns.org/latest?base=EUR

This app List all currencies you get from the endpoint (one per row). Each row has an input where you
can enter any amount of money. When you tap on currency row it will slide to top and its
input becomes first responder. When you’re changing the amount the app will simultaneously
update the corresponding value for other currencies.


# Technologies used

This project is developped in Kotlin, and uses MVVM Architecture
# Main features used

* Dagger2
* RxJava2
* Retrofit2
* Espresso
* DataBinding
* Timber

Here is the Video demo: https://youtu.be/omcS-6LeKoo
